// CV Burning Animation Effect
class CVBurningEffect {
    constructor(element) {
        this.element = element;
        this.particles = [];
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.setup();
    }

    setup() {
        this.canvas.style.position = 'absolute';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';
        this.canvas.style.pointerEvents = 'none';
        this.element.appendChild(this.canvas);
        this.resize();
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        this.width = this.canvas.width = this.element.offsetWidth;
        this.height = this.canvas.height = this.element.offsetHeight;
    }

    createParticle(x, y) {
        return {
            x,
            y,
            vx: (Math.random() - 0.5) * 2,
            vy: -Math.random() * 2 - 2,
            size: Math.random() * 3 + 1,
            alpha: 1
        };
    }

    animate() {
        if (this.isAnimating) {
            this.ctx.clearRect(0, 0, this.width, this.height);

            // Create new particles
            if (Math.random() < 0.3) {
                const x = Math.random() * this.width;
                const y = this.height;
                this.particles.push(this.createParticle(x, y));
            }

            // Update and draw particles
            for (let i = this.particles.length - 1; i >= 0; i--) {
                const p = this.particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.alpha *= 0.98;

                this.ctx.fillStyle = `rgba(255, 140, 0, ${p.alpha})`;
                this.ctx.beginPath();
                this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                this.ctx.fill();

                if (p.alpha < 0.01) {
                    this.particles.splice(i, 1);
                }
            }

            requestAnimationFrame(() => this.animate());
        }
    }

    start() {
        if (!this.isAnimating) {
            this.isAnimating = true;
            this.particles = [];
            this.animate();
        }
    }

    stop() {
        this.isAnimating = false;
    }
}

// Initialize burning effect on CV animation container
document.addEventListener('DOMContentLoaded', () => {
    const cvContainer = document.getElementById('cvAnimation');
    if (cvContainer) {
        const burningEffect = new CVBurningEffect(cvContainer);
        
        cvContainer.addEventListener('mouseenter', () => {
            burningEffect.start();
        });

        cvContainer.addEventListener('mouseleave', () => {
            burningEffect.stop();
        });
    }
});

// Arrow bounce animation
function initArrowAnimations() {
    document.querySelectorAll('.arrow').forEach(arrow => {
        arrow.addEventListener('mouseenter', () => {
            arrow.style.animation = 'bounce 0.5s infinite';
        });

        arrow.addEventListener('mouseleave', () => {
            arrow.style.animation = '';
        });
    });
}

// Page transition animations
function initPageTransitions() {
    const transition = document.createElement('div');
    transition.className = 'page-transition exit';
    document.body.appendChild(transition);

    window.addEventListener('load', () => {
        setTimeout(() => {
            transition.classList.add('exit');
        }, 500);
    });
}

// Initialize all animations
document.addEventListener('DOMContentLoaded', () => {
    initArrowAnimations();
    initPageTransitions();
}); 